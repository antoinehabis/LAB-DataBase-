
Methode_horner =function(x,Tab){
    if (length(Tab)==1){
        return (Tab[1])}
    else{
        return (Tab[1]+x*Methode_horner(x,Tab[2:length(Tab)]))}
}

load('projectData.Rdata')
source('evalTools.R')

Methode_horner_Newton=function(Tabc,Tabx,x){
    ###permet d'évaluer le polynome 
    ### Tabc contient les c_k 
    ### Tabx contient les x_k
    if(length(Tabx)==1){
        Tabc[1]+(x-Tabx[1])    }
    else{
        return (Tabc[1]+(x-Tabx[1])*Methode_horner_Newton(Tabc[2:length(Tabc)],Tabx[2:length(Tabx)],x))
    }
}

dividif=function(x,y){
    ## Newton's Divided differences
    ## @param x: a vector containing the interpolation nodes
    ## @param y: a vector of same size as x:
    ## values of the interpolated function at the nodes
    ## @return : a vector of same size as x:
    ## the divided differences
    ## \eqn{f_[x_0, ... x_k]} of order 'length(x) -1'.
  n = length(x)-1
  d = y
  if (n==0){return(d)}
  M=matrix(ncol = n+1,nrow = n+1)
  M[,1] = y
  for (j in 2:(n+1)){
  M[,j] = M[,j-1]
  for (i in (j):(n+1)){
    M[i,j] = (M[i,j-1]-M[i-1,j-1])/(x[i]-x[i-j+1])
  }
  }
  return(M[,n+1])
}

evalX=function(x){
    return (GRILLE[getIndex(x)])
}

noeud_de_tchb=function(a,b,n)
    return (((a+b)/2)+((b-a)/2)*cos(((0:n)+(1/2))*pi/(n+1)))

##### Cette fonction va me servir dans la question 2.a#############
## elle me permet d'évaluer l'interpolation avec les bonnes différences divisées
decouper=function(L,a,b){
    k1=1
    k2=1
    if (L[1]>a){}
    else{
        while(L[k1]<a){
        k1=k1+1
    }
    }
    if (L[length(L)]<=b){k2=length(L)}
    else{
        
    while(L[k2]<b){
        k2=k2+1
    }
    }
    L=c(k1,k2)
    return (L)
    
}
minimiser_erreur=function(n,type){
    c=(1:n)
    for (i in (1:n)){
    if (type=="cheby"){
    Tab_noeuds=noeud_de_tchb(a,b,i)}
    if (type=="equi"){
    Tab_noeuds=seq(a, b, length.out =i+1)
    }
    Tab_x=sapply(Tab_noeuds,FUN=evalX)
    Tab_y=sapply(Tab_x,FUN=evalHeight)
    Tab_c=dividif(Tab_x,Tab_y)
    X_arange=sapply(seq(a,b,length.out=10000),FUN=evalX)
    Y_interpol=Methode_horner_Newton(Tab_c,Tab_x,X_arange)
    Y=sapply(X_arange,FUN=evalHeight)
    c[i]=max(sapply(Y-Y_interpol,abs))
    }
    return(which(c==min(c)))
}


interpolation_morceau=function(p,n,type="equi",plot=FALSE){
    #####p correspond aux nombres de points dans les intervalles
    #####n correspond aux nombres d'intervalles
    ##### p*n-n+1 correspond au nombre de points en tout
    ##### elle retourne la valeur de l'erreur minimale
    if (type=="equi"){
    Tab_noeuds=seq(a, b, length.out =p*n-n+1 )
    }
    if (type=="cheby"){
    Tab_noeuds=rev(noeud_de_tchb(a,b,p*n-n))}

    X_arange=seq(evalX(Tab_noeuds[1]),evalX(Tab_noeuds[length(Tab_noeuds)]),length.out =500)
    X_arange=sapply(X_arange,FUN=evalX)
    Y=sapply(X_arange,FUN=evalHeight)
    
    n1 <- p
    n2 <- n
    Tab_c <- matrix (rep(0, n1*n2), n1, n2)       
    Y_interpol=c()
    
    
    for (i in (0:(n-1))){
        Tab_x=sapply(Tab_noeuds,evalX)
        Tab_y=sapply(Tab_x,evalHeight)
        Tab_c[,(i+1)]=dividif(Tab_x[(i*(p-1)+1):((i+1)*(p-1)+1)],Tab_y[(i*(p-1)+1):((i+1)*(p-1)+1)])
        a1=decouper(X_arange,Tab_x[i*(p-1)+1],Tab_x[(i+1)*(p-1)+1])[1]
        b1=decouper(X_arange,Tab_x[i*(p-1)+1],Tab_x[(i+1)*(p-1)+1])[2]
        if (b1<length(X_arange)){
            for (j in a1:(b1-1)){
            Y_interpol=c(Y_interpol,Methode_horner_Newton(Tab_c[,(i+1)],Tab_x[(i*(p-1)+1):((i+1)*(p-1)+1)],X_arange[j]))
            }}

        
        else{
            for (j in (a1:b1)){
        Y_interpol=c(Y_interpol,Methode_horner_Newton(Tab_c[,(i+1)],Tab_x[(i*(p-1)+1):((i+1)*(p-1)+1)],X_arange[j]))
            }

        }
                }
    if (plot==TRUE){
    plot(X_arange,Y)
    lines(X_arange,Y_interpol,col="blue")
    legend(x="topleft",c("interpolation","Height"),col=c("blue","black"),lty=c(1,1),bty="x")
    title('représentation de Height et de son interpolation')
        }
    options(warn=-1)
    return (max(sapply(Y-Y_interpol,abs)))
    }


### Cette fonction va m'être utile pour observer tous les cas possibles 
###de nombres de points dans un intervalle et de nombres d'intervalles 
###pour un nombre de points donné.



### Cette fonction retourne les diviseurs de n 
diviseur=function(n){
    L=c()
    for (i in (1:n)){
        if (n%%i==0){
            L=c(L,i)
        }
    }
    return(L)
}


trapezeInt =function(FUN,a,b,M){
    x = seq(a,b, length.out= M+1)
    y = sapply(x, FUN)
    h = (b-a)/M 
    q =h*sum(y)
    q=q-h*(1/2)*(FUN(a)+FUN(b))
    return(q)
}

refineTrapeze=function(FUN,a,b,M,q){
    ##' refinement of the subdivision step: incremental method
    ##' @param FUN : the function to be integrated
    ##' @param a, b : interval end points 
    ##' @param M : initial number of intervals (each of size (b-a)/M)
    ##'  having been used to compute q
    ##' @param  q : the value of the trapezoidal  quadrature method
    ##'  of stepsize (b-a)/M
    ##' @return : the value of the quadrature for a stepsize h' = h/2
    h = (b-a)/M
    H=sapply(a+(2*(0:(M-1))+1)*h/2,FUN)
    Q = q/2 +(h/2)*sum(H)

    return(Q)
}

simpsonInt = function(FUN,a,b,M){
    ##' Simpson integration via trapeze rule
    ##' uses the fact that 
    ##' simpson(h) = 4/3(trapeze(h/2) - 1/4 trapeze(h))
    h = (b-a)/M
    qtrapeze =trapezeInt(FUN,a,b,M)
    qrefined =refineTrapeze(FUN,a,b,M,qtrapeze)
    q =  (4/3)*(qtrapeze-(1/4)*qrefined)
    print('caca')
    return(q)
}

evalErrSimpson=function(FUN,a,b,M){
  ## Computes an approximation E of the error 
  ## for the composite Simpson rule of step h=(b-a)/(2M). 
  ##This requires computing I_M and I_{2M}. 
  ##The value  q = I_{2M} is also returned. 
  qth = trapezeInt(FUN,a,b,M)   ## M +1 evaluations
  qth2 = refineTrapeze ( FUN,a,b,M,qth )  ## M evaluations
  qth4 = refineTrapeze ( FUN,a,b,2*M,qth2 )   ## 2M evaluations
  simps_h =   4/3*(qth2 - 1/4* qth ) 
  simps_h2 =  4/3*(qth4 - 1/4* qth2 )  
  q = simps_h2  
  E = (1/15) *(simps_h - simps_h2)  
    return(c(E,q))
}
